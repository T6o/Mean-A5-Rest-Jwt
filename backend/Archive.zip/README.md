Stop Mongod
pgrep mongo
sudo kill pid

DEBUG
- node --inspect server.js
- about:inspect (chrome)
- inspect (under Target)
- insert break-point and reload localhost:PORT

per autenticazione
http://blog.slatepeak.com/creating-a-simple-node-express-api-authentication-system-with-passport-and-jwt/
