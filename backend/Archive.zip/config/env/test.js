// Invoke 'strict' JavaScript mode
'use strict';

// Set the 'test' environment configuration object
module.exports = {
	db: 'mongodb://localhost/myprog-test',

	/*db : 'mongodb://t6o:Thcmt_6@' +
	'cluster0-shard-00-00-aqcvk.mongodb.net:27017,'+
	'cluster0-shard-00-01-aqcvk.mongodb.net:27017'+
	',cluster0-shard-00-02-aqcvk.mongodb.net:27017/test?'+
	'ssl=true&replicaSet=Cluster0-shard-0&authSource=admin',*/

	sessionSecret: 'testSessionSecret',
	expiresIn:'15m',
	sendgrid:'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',

	facebook: {
		clientID: 'Facebook Application ID',
		clientSecret: 'Facebook Application Secret',
		callbackURL: 'http://localhost:3000/oauth/facebook/callback'
	},
	twitter: {
		clientID: 'Twitter Application ID',
		clientSecret: 'Twitter Application Secret',
		callbackURL: 'http://localhost:3000/oauth/twitter/callback'
	},
	google: {
		clientID: 'Google Application ID',
		clientSecret: 'Google Application Secret',
		callbackURL: 'http://localhost:4200/oauth/google/callback'
	}
};
