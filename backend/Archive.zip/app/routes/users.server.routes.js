// Invoke 'strict' JavaScript mode
'use strict';

// Load the module dependencies
var users = require('../../app/controllers/users.server.controller'),
  passport = require('passport');

// Define the routes module' method
module.exports = function(app) {

  app.route('/signup')
    .post(users.signup);

  app.route('/signin')
    .post(users.signin);

  app.route('/forgotpw')
    .post(users.forgotpw);

  app.route('/resetpw')
    .post(users.resetpw);

  app.route('/verify')
    .post(users.verify);

  app.route('/profile')
    .post(users.getProfile);

  app.route('/socialToken')
    .get(users.socialToken);

  //  app.route('/google')
  //    .get(users.google());

  app.get('/oauth/facebook', passport.authenticate('facebook', {
    failureRedirect: '/signin'
  }));

  app.get('/oauth/facebook/callback', passport.authenticate('facebook', {
    failureRedirect: '/signin',
    successRedirect: '/'
  }));

  app.get('/oauth/twitter', passport.authenticate('twitter', {
    failureRedirect: '/signin'
  }));

  app.get('/oauth/twitter/callback', passport.authenticate('twitter', {
    failureRedirect: '/signin',
    successRedirect: '/'
  }));

  app.get('/oauth/google', passport.authenticate('google', {
    /*scope: [
      'https://www.googleapis.com/auth/userinfo.profile',
      'https://www.googleapis.com/auth/userinfo.email'
    ],*/
  }));

  app.get('/oauth/google/callback', passport.authenticate('google', {
    failureRedirect: '/signin',
    successRedirect: '/'
  }));

};
