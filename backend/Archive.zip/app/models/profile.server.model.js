'use strict';

var mongoose = require('mongoose'),
  bcrypt = require('bcrypt'),
  Schema = mongoose.Schema;

var ProfileSchema = new mongoose.Schema({
  firstName: {
    type: String,
  },
  lastName:{
    type: String,
  },
  email: {
    type: String,
    lowercase: true,
    unique: true,
    match: [/.+\@.+\..+/, "Please fill a valid email address"]
  },
  role: {
    type: String,
    enum: ['Client', 'Manager', 'Admin'],
    default: 'Client'
  }

});

mongoose.model('Profile', ProfileSchema);
